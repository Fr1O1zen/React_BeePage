import React, {useEffect} from 'react';
import "./Pasieka.css";
import NavBar from '../NavBar';
import MyFooter from '../MyFooter';
import Aos from "aos";
import ArrowPageUp from '../ArrowPageUp';
import "aos/dist/aos.css";
function Pasieka(props) {
    useEffect(()=>{
        Aos.init({duration:300});
     },[]);
    return (
   <>
    <NavBar className='PasiekaNavbar'/>
        <div className='PasiekaCarousel'>
        </div>
        <div className='PasiekaDescription'>
            <h1 className='PasiekaHeader' data-aos="fade-right"> Pasieka ZohFroz</h1>
            <div className='PasiekaDescriptionPaperCard'>
            <p className="DescriptionParagraph">Lorem Ipsum is simply dummy text of the printing and typesetting industry.
             Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
              when an unknown printer took a galley of type and scrambled it to make a type specimen book.
               It has survived not only five centuries, but also the leap into electronic typesetting,
                remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset
                 sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like
                  Aldus PageMaker including versions of Lorem Ipsum.</p> 
                  <p className="DescriptionParagraph">Lorem Ipsum is simply dummy text of the printing and typesetting industry.
             Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
              when an unknown printer took a galley of type and scrambled it to make a type specimen book.
               It has survived not only five centuries, but also the leap into electronic typesetting,
                remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset
                 sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like
                  Aldus PageMaker including versions of Lorem Ipsum.</p> 
            </div>
        </div>
        <MyFooter/>
        <ArrowPageUp/>
   </>
    );
}

export default Pasieka;