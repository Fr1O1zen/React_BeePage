import React, {useEffect} from 'react';
import "./Contact.css";
import NavBar from '../NavBar';
import ArrowPageUp from '../ArrowPageUp';
import MyFooter from '../MyFooter';
import Aos from "aos";
import "aos/dist/aos.css";
function Contact(props) {
    useEffect(()=>{
        Aos.init({duration:350});
     },[]);
    return (
   <>
    <NavBar/>
    <div className='ContactCarousel'></div>
    <div className='ContactArea'>
        <h1 className='ContactHeader' data-Aos='fade-right'>Kontakt</h1>
        <div className='ContactPaperCard'>
            <p className='ContactParagraph'>Facebook : <a href='#' 
            style={{
                color:'black',
                fontFamily:'Arial',
            }}>
                  Link HERE</a></p>
            
            <p className='ContactParagraph'>Gmail :
            <a href='#' 
            style={{
                color:'black',
                fontFamily:'Arial',
            }}>
                  Link HERE</a></p>
        </div>
    </div>
    <ArrowPageUp/>
    <MyFooter/>
   </>
    );
}

export default Contact;