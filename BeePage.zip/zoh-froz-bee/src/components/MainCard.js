import React, {useEffect} from 'react';
import "./MainCard.css";
import beekeeper from '../photos/beekeeper.jpg';
import HoneyJar from '../photos/HoneyJar.jpg';
import Plaster from '../photos/plastermiodu.jpg';
import Aos from "aos";
import "aos/dist/aos.css";
const InitialStateItems=[
    {
    picture:beekeeper,
    description:'Lorem ipsum dolor sit asdasdasdasdasdasdasdasdamet qusine vehicula lacis nec pertium',
    },
    {
    picture:HoneyJar,
    description:'Lorem ipsum dolor sit amet qusineasdasdasdasdasdasdasdasdasd vehicula lacis nec pertium',
    },
    {
    picture:Plaster,
    description:'Lorem ipsum dolor sit amet qusineasdasdasdasdasdasdasdasd vehicula lacis nec pertium',
    },
];
function MainCard(props) {
    useEffect(()=>{
        Aos.init({duration:500});
     },[]);
    return (
        <div data-aos="fade-in">
            <div  className="CardMain">
            <img className="CardMain__photo" src={InitialStateItems[props.value].picture} alt=" Honey HERE :( " />
            <p className="CardMain__desc">{InitialStateItems[props.value].description}</p>
            </div>
        </div>
    );
}

export default MainCard;