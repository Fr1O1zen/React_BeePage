import React from 'react';
import "./ArrowPageUp.css";
import ScrollUpButton from "react-scroll-up-button";
function ArrowPageUp(props) {
    return (
        <div>
        <ScrollUpButton
      StopPosition={0}
      ShowAtPosition={0}
      EasingType='easeOutCubic'
      AnimationDuration={300}
      ContainerClassName='ArrowPageUp '
            />
        </div>
    );
}

export default ArrowPageUp;