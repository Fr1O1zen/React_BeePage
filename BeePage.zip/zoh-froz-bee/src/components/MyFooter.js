import React from 'react';
import "./MyFooter.css";
import facebook from '../icons/facebook.png';
import instagram from '../icons/Instagram.png';
import gmail from '../icons/Gmail.png';
import Logo from '../icons/Logo.png';
function MyFooter(props) {
    return (
        <div className="FooterApp">
            <div className="FooterDesc">Lorem ipsum dolro sit
            <p> Lorem ipsum dolro sit
            Lorem ipsum dolro sit
            Lorem ipsum dolro sit 
            Lorem ipsum dolro sit</p>
            <img src={Logo} width='150px'/>
            </div>
            <div className="SocialIcons">
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"><img src={facebook} className='SocialIconImg'  alt="FBicon"/></a>
                <a  href="https://Instagram.com"  target="_blank" rel="noopener noreferrer"><img src={instagram} className='SocialIconImg'  alt="Instaicon"/></a>
                <a  href="https://Gmail.com"  target="_blank" rel="noopener noreferrer"><img src={gmail} className='SocialIconImg' alt="GMicon"/></a>
            </div>
        </div>
    );
}

export default MyFooter;