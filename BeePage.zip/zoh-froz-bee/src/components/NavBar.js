import React, { useState } from 'react';
import './NavBar.css';
import { mdiHomeOutline } from '@mdi/js';
import Icon from '@mdi/react';
import Logo from '../icons/Logo.png';
import { NavLink } from 'react-router-dom';

function NavBar(props) {
    const [Burger,setBurger]= useState(false);

    return (
        
        <>
        
        <div className="NavBarWrapper">
        <div className="NavMain">
            <div className="NavLogo">
            <img src={Logo} />
            </div>
            <ul className="Nav_ul_wrapper">
                <li className="Nav_ul_item"><NavLink className="RouterLink" to=''><Icon id="HomeIconNav" path={mdiHomeOutline} size={2}/></NavLink></li>
                <li className="Nav_ul_item"><NavLink className="RouterLink" to="/components/PasiekaCard/Pasieka">Pasieka</NavLink></li>
                <li className="Nav_ul_item"><NavLink className="RouterLink" to='/components/KontaktCard/Contact'>Kontakt</NavLink></li>
                <li className="Nav_ul_item"><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
            </ul>
                    <div className="NavBurgerParent" onClick={()=>{setBurger(!Burger)}}>
                    <span className="NavBurger" id={Burger ? 'NavBurger1' : ''}></span>
                    <span className="NavBurger" id={Burger ? 'NavBurger2' : ''}></span>
                    <span className="NavBurger" id={Burger ? 'NavBurger3' : ''}></span>
                    </div>
        </div>
        </div>
        <ul className={Burger ? 'Nav_ul_wrapper__mobile__active' : 'Nav_ul_wrapper__mobile'}>
                <li className="Nav_ul_item"><NavLink className="RouterLink" to=''><Icon id="HomeIconNav" path={mdiHomeOutline} size={1.5}/></NavLink></li>
                <li className="Nav_ul_item"><NavLink className="RouterLink" to="/components/PasiekaCard/Pasieka">Pasieka</NavLink></li>
                <li className="Nav_ul_item"><NavLink className="RouterLink" to='/components/KontaktCard/Contact'>Kontakt</NavLink></li>
                <li className="Nav_ul_item"><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
            </ul>
        </>
    );
}

export default NavBar;