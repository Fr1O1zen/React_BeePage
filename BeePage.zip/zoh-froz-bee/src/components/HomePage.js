import React, {useEffect} from 'react';
import "./main.css";
import MainCard from './MainCard';
import Aos from "aos";
import "aos/dist/aos.css";
import NavBar from './NavBar';
import GifCarousel from './GifCarousel';
import MyFooter from './MyFooter';
import ArrowPageUp from './ArrowPageUp';

function HomePage(props) {
          useEffect(()=>{
            Aos.init({duration:300});
         },[]);

    return (
        <>     
      <NavBar/>
      <GifCarousel/>
        <div className="MainSection">
        <h1 data-aos="fade-right" style={{color:'black',borderBottom:'1px solid'}} className="MainSectionHeader">LOREM IPSUM DOLOR</h1>
            <div className="MainSectionInsider">
                <MainCard value={0}/>
                <MainCard value={1}/>
                <MainCard value={2}/>
            </div>
        </div>


        <div className="MainSection2">
            <div className="MainSectionInsider2">
                <h1 data-aos="fade-right" className="MainSectionHeader">LOREM IPSUM DOLOR</h1>
                <div data-aos="fade-up" className="TextAreaSection2">
                    L. Lor00s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                 It has survived not only five centuries, but also the leap into electronic typesetting,
                  remaining essentially unchanged.
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                  Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                   when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                    It has survived not only five centuries, 
                  but also the leap into electronic typesetting, remaining essentially unchanged.  
                  </div>
            </div>
        </div>


        {/* <div className="MainSection3">
            <h3 data-aos="fade-right" className="MainSectionHeader">akjsdhajksldh</h3>
        </div> */}

        <MyFooter/>
      <ArrowPageUp/>
        </>
    );
}

export default HomePage;
