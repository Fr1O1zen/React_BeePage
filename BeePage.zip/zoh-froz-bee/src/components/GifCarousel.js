import React from 'react';
import "./GifCarousel.css";
import BeeMovie from '../videos/Beemovie.mp4';
import HivesMobile from '../photos/HivesMobile.png';

function GifCarousel(props) {
    return (
        <div className="JumboVideoWrapper">
            <video  className="JumboVideo"   autoPlay muted loop>
            <source src={BeeMovie} type="video/mp4"/>
            Your browser does not support the video tag.
            </video>
            <img style={{zIndex:'-1'}} src={HivesMobile} className="HivesMobile__mobile"  alt="Ule pszczelarza zdj"/>
            <div className='CarouselText'>
                <h1>Pasieka ZohFroz</h1>
                <h3>Pasja, innowacja, ekologia</h3>
            </div>
        </div>
    );
}

export default GifCarousel;