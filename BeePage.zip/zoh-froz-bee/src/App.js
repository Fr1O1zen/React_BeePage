import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';
import HomePage from './components/HomePage';
import Contact from './components/KontaktCard/Contact';
import Pasieka from './components/PasiekaCard/Pasieka';
function App() {
  return (
    <>
  <Router>
    <Switch>
      <Route exact path="/" component={HomePage} />
      <Route path="/components/KontaktCard/Contact" component={Contact} />
      <Route path="/components/PasiekaCard/Pasieka" component={Pasieka} />
    </Switch>
  </Router>
    </>
  );
}

export default App;
